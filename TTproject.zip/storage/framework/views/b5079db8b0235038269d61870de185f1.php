<div class="card mb-3 shadow-sm">
    <div class="card-body">
        <h5 class="card-title"><?php echo e($offer->name); ?></h5>
        <h6 class="card-subtitle mb-2 text-muted"><?php echo e($offer->price); ?>€</h6>
        <img src="<?php echo e(asset('storage/' . $offer->imagePath)); ?>" alt="Image" width="250">
        <a href="<?php echo e(route('offer.show', $offer->id)); ?>" class="btn btn-primary">Details</a>
    </div>
</div><?php /**PATH /var/www/html/TTproject/resources/views/components/offer-card.blade.php ENDPATH**/ ?>