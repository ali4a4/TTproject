<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Marketplace']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Marketplace']); ?>
     <?php $__env->slot('title', null, []); ?> Marketplace <?php $__env->endSlot(); ?>
    <h1 class="mb-4">Marketplace</h1>
    <div class="d-flex">
        <form action="<?php echo e(route('offer.index')); ?>" method="GET">
            <button type="submit" class="btn btn-primary" style="width: 308px;">Sort</button>
            <div class="d-flex">
                <div>
                    <select name="product_category_id" class="custom-select" size="15" multiple>
                        <option value="">All</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"<?php echo e(request('product_category_id') == $category->id ? 'selected' : ''); ?>><?php echo e($category->category); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <select name="latvian_region_id" class="custom-select" size="46" multiple>
                        <option value="">All</option>
                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($region->id); ?>"<?php echo e(request('latvian_region_id') == $region->id ? 'selected' : ''); ?>><?php echo e($region->region); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </form>
        <div>
            <?php if($offers->count()): ?>
                <div class="row">
                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <?php if (isset($component)) { $__componentOriginal89efc9f6ed29145134491c1550a071e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal89efc9f6ed29145134491c1550a071e2 = $attributes; } ?>
<?php $component = App\View\Components\OfferCard::resolve(['offer' => $offer] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('offer-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\OfferCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal89efc9f6ed29145134491c1550a071e2)): ?>
<?php $attributes = $__attributesOriginal89efc9f6ed29145134491c1550a071e2; ?>
<?php unset($__attributesOriginal89efc9f6ed29145134491c1550a071e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal89efc9f6ed29145134491c1550a071e2)): ?>
<?php $component = $__componentOriginal89efc9f6ed29145134491c1550a071e2; ?>
<?php unset($__componentOriginal89efc9f6ed29145134491c1550a071e2); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">No offers available</div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH /var/www/html/TTproject/resources/views/offers/index.blade.php ENDPATH**/ ?>