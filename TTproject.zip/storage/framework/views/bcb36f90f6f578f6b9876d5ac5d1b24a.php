<nav class="bg-secondary p-3 d-flex justify-content-between">
    <div>
        <a href="<?php echo e(route('offer.index')); ?>" class="btn btn-primary"><b>Marketplace</b></a>
        <?php if(auth()->guard()->check()): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\Offer::class)): ?>
                <a href="<?php echo e(route('offer.create')); ?>" class="btn btn-primary"><b>Create offer</b></a>
            <?php endif; ?>
    </div>
    <div>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary"><b>Logout</b></button>
            </form>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
    </div>
    <div>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary"><b>Login</b></a>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-primary"><b>Register</b></a>
        <?php endif; ?>
    </div>
</nav><?php /**PATH /var/www/html/TTproject/resources/views/components/nav-bar.blade.php ENDPATH**/ ?>