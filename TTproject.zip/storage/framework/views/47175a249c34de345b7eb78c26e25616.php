<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo e($title); ?></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <div id="google_translate_element" class="bg-secondary"></div>
        <script type="text/javascript">
            function googleTranslateElementInit() {
                new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
            }
        </script>
        <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        <?php if (isset($component)) { $__componentOriginal850419188ae35167c7319eecf5d82db1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal850419188ae35167c7319eecf5d82db1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-bar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal850419188ae35167c7319eecf5d82db1)): ?>
<?php $attributes = $__attributesOriginal850419188ae35167c7319eecf5d82db1; ?>
<?php unset($__attributesOriginal850419188ae35167c7319eecf5d82db1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal850419188ae35167c7319eecf5d82db1)): ?>
<?php $component = $__componentOriginal850419188ae35167c7319eecf5d82db1; ?>
<?php unset($__componentOriginal850419188ae35167c7319eecf5d82db1); ?>
<?php endif; ?>
        <main class="container-fluid bg-light"><?php echo e($slot); ?></main>
    </body>
</html><?php /**PATH /var/www/html/TTproject/resources/views/components/layout.blade.php ENDPATH**/ ?>